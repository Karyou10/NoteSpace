import { Link } from "react-router";
import LandingPageHeader from "../components/LandingPageHeader";
import Footer from "../components/Footer";

export default function HelpCentre() {
  return (
    <div className="bg-[#fefefe] flex flex-col min-h-screen w-full">
      <LandingPageHeader />
      
      <main className="flex flex-col items-center w-full flex-1 px-[112px] py-[88px]">
        <div className="max-w-[1216px] w-full">
          <h1 className="font-['Inter:Bold',sans-serif] font-bold text-[56px] text-[#545454] leading-[1.4] mb-[24px]">
            Help Centre
          </h1>
          <p className="font-['Inter:Regular',sans-serif] font-normal text-[20px] text-[#909090] leading-[1.6] mb-[48px]">
            Get help with using NoteSpace and find answers to your questions.
          </p>
          
          <div className="flex items-center justify-center py-[120px]">
            <div className="text-center">
              <p className="font-['Inter:Medium',sans-serif] font-medium text-[24px] text-[#909090] leading-[1.6] mb-[32px]">
                Help Centre coming soon
              </p>
              <Link to="/" className="bg-[#f97316] inline-flex gap-[8px] h-[48px] items-center justify-center px-[32px] py-[8px] rounded-[16px] hover:bg-[#e06814] transition-colors">
                <p className="font-['Inter:Medium',sans-serif] font-medium leading-[1.6] text-[#fefefe] text-[14px] whitespace-nowrap">
                  Back to Home
                </p>
              </Link>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
