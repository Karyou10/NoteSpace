import imgStanford1 from "figma:asset/3694efa050ed2647e7677aa9ad276addd3b421f9.png";
import imgToronto1 from "figma:asset/239faf4834a94b6e4ac0f408f92f9611eed24442.png";
import imgMelbourne1 from "figma:asset/fdaf34cee24e94ad39945b2e1a7f21b04f7fb3fd.png";
import imgEth1 from "figma:asset/359699e69525ceea49e2f47d8dd515f811cffb76.png";
import imgUct1 from "figma:asset/30600201c5e807a9cfb79f2988597593b3756f5d.png";
import imgNus1 from "figma:asset/72b7051fd99a2cbd0aaace36e2d1da52053304a3.png";
import svgPaths from "../../imports/svg-81u4lsk3wh";

function TrustedBadge() {
  return (
    <div className="bg-[#fef1e8] content-stretch flex gap-[16px] items-center justify-center px-[16px] py-[8px] relative rounded-[16px] shrink-0">
      <div className="relative shrink-0 size-[24px]" data-name="GraduationCap">
        <div className="absolute inset-[9.38%_0_3.12%_0]" data-name="Vector">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.9995 20.9999">
            <path d={svgPaths.p2941e500} fill="var(--fill-0, #C75C12)" id="Vector" />
          </svg>
        </div>
      </div>
      <div className="flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] not-italic relative shrink-0 text-[#c75c12] text-[14px] whitespace-nowrap">
        <p className="leading-[1.6]">{`Trusted by 10,000+ students & educators`}</p>
      </div>
    </div>
  );
}

function SectionHeading() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start leading-[0] not-italic relative shrink-0 text-center w-full">
      <div className="flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center relative shrink-0 text-[#545454] text-[32px] w-full">
        <p className="leading-[1.5]">Used at top universities worldwide</p>
      </div>
      <div className="flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center relative shrink-0 text-[#909090] text-[20px] w-full">
        <p className="leading-[1.6]">Students and teachers from leading institutions rely on NoteSpace every day</p>
      </div>
    </div>
  );
}

function LogoCarousel() {
  return (
    <div className="flex gap-[32px] items-center animate-[scroll_30s_linear_infinite]">
      <div className="h-[38px] relative shrink-0 w-[39px]">
        <img alt="Stanford University" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgStanford1} />
      </div>
      <div className="relative shrink-0 size-[42px]">
        <img alt="University of Toronto" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgToronto1} />
      </div>
      <div className="h-[42px] relative shrink-0 w-[49px]">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="University of Melbourne" className="absolute h-[200%] left-[-35.71%] max-w-none top-[-50%] w-[171.43%]" src={imgMelbourne1} />
        </div>
      </div>
      <div className="h-[20px] relative shrink-0 w-[105px]">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="ETH Zurich" className="absolute h-[630%] left-[-10.38%] max-w-none top-[-270%] w-[118.87%]" src={imgEth1} />
        </div>
      </div>
      <div className="h-[40px] relative shrink-0 w-[70px]">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="University of Cape Town" className="absolute h-[226.92%] left-[-15.56%] max-w-none top-[-57.69%] w-[131.11%]" src={imgUct1} />
        </div>
      </div>
      <div className="h-[34.56px] relative shrink-0 w-[27px]">
        <img alt="National University of Singapore" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgNus1} />
      </div>
      <div className="h-[20px] relative shrink-0 w-[105px]">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="ETH Zurich" className="absolute h-[630%] left-[-10.38%] max-w-none top-[-270%] w-[118.87%]" src={imgEth1} />
        </div>
      </div>
      <div className="h-[38px] relative shrink-0 w-[39px]">
        <img alt="Stanford University" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgStanford1} />
      </div>
      <div className="relative shrink-0 size-[42px]">
        <img alt="University of Toronto" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgToronto1} />
      </div>
    </div>
  );
}

function LogoCarouselWithGradient() {
  return (
    <div className="relative h-[42px] w-[592px] overflow-hidden">
      <div className="absolute flex gap-[32px] whitespace-nowrap">
        <LogoCarousel />
        <LogoCarousel />
      </div>
      <div className="absolute inset-0 pointer-events-none" style={{ backgroundImage: "linear-gradient(90deg, rgb(254, 254, 254) 0%, rgba(254, 254, 254, 0) 15%, rgba(254, 254, 254, 0) 85%, rgb(254, 254, 254) 100%)" }} />
    </div>
  );
}

export default function UniversityLogos() {
  return (
    <div className="content-stretch flex flex-col gap-[24px] items-center relative shrink-0 w-[734px]">
      <TrustedBadge />
      <div className="content-stretch flex flex-col gap-[32px] items-center relative shrink-0 w-full">
        <SectionHeading />
        <LogoCarouselWithGradient />
      </div>
    </div>
  );
}